# T3-JEE
![1](https://github.com/Zahira-fa/T3-JEE/assets/64859107/af5fcd76-77ca-4978-aee0-630a7dc48407)
![2](https://github.com/Zahira-fa/T3-JEE/assets/64859107/1a574a87-ff6e-43ed-8b41-f4773b252fa6)
# La Recherche
![3](https://github.com/Zahira-fa/T3-JEE/assets/64859107/46dad2e9-04ab-4886-8619-134ce784c3f5)
# La fonction Delete
![4](https://github.com/Zahira-fa/T3-JEE/assets/64859107/cf1361dd-05da-47a6-9d34-9a2b882e313d)
# Capture de base données.
![5](https://github.com/Zahira-fa/T3-JEE/assets/64859107/0ff56d5c-7667-42a3-bb4f-79e68058780a)
